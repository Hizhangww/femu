## save to .dat file
import struct
import os
import sys


#sudo nvme write /dev/nvme0n1 -s 1738079 -c 0 -z 4096 -d write.txt

def read_file(file_addr):
    if not os.path.exists(file_addr):
        print('no file')
        return 0
    else:
        fopen = open(file_addr, 'r')
        lines = fopen.readlines()
        length = 0
        lba = 0
        total_page = 0
        for line in lines:
            if line[0] == "L":
                line = line.strip('\n')
                length = line[2:]
                total_page += int(length) + 1
            if line[0] == "W":
                line = line.strip('\n')
                lba = line[2:]
                sys_call(lba,length)
        return total_page
def sys_call(lba,length):

    str_call = 'sudo nvme write /dev/nvme0n1 -s {} -c {} -z 4096 -d write.txt'.format(lba,length)
    val = os.system(str_call)
    print(str_call)

if __name__ == '__main__':
    total_pages = 0
    for i in range(0,289):
        total_page = read_file('Data{}.log'.format(i))
        total_pages += total_page
        if total_pages >= 20000000:
            break
    print(total_pages)





















